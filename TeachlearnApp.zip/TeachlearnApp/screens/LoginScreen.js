import React, { useState } from 'react';
import { View, Text, TextInput, Button, StyleSheet } from 'react-native';

export default function LoginScreen() {
  const [phone, setPhone] = useState('');
  const [state, setState] = useState('');
  const [language, setLanguage] = useState('');

  const handleLogin = () => {
    console.log('Login pressed');
    // Here we can add Firebase Auth and navigation
  };

  return (
    <View style={styles.container}>
      <Text style={styles.title}>TeachLearn Login</Text>
      <TextInput
        style={styles.input}
        placeholder="Parent's Phone Number"
        keyboardType="phone-pad"
        onChangeText={setPhone}
      />
      <TextInput
        style={styles.input}
        placeholder="Select State (e.g. Maharashtra)"
        onChangeText={setState}
      />
      <TextInput
        style={styles.input}
        placeholder="Select Language (e.g. English)"
        onChangeText={setLanguage}
      />
      <Button title="Login" onPress={handleLogin} />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    padding: 20,
  },
  title: {
    fontSize: 24,
    marginBottom: 20,
    textAlign: 'center',
  },
  input: {
    borderWidth: 1,
    borderColor: '#ccc',
    padding: 10,
    marginBottom: 10,
    borderRadius: 5,
  },
});